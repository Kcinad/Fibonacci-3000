﻿namespace Fibonacci
{
    internal class Program
    {
        const string TITLE = @"   ▄████████  ▄█  ▀█████████▄   ▄██████▄  ███▄▄▄▄      ▄████████  ▄████████  ▄████████  ▄█  
  ███    ███ ███    ███    ███ ███    ███ ███▀▀▀██▄   ███    ███ ███    ███ ███    ███ ███  
  ███    █▀  ███▌   ███    ███ ███    ███ ███   ███   ███    ███ ███    █▀  ███    █▀  ███▌ 
 ▄███▄▄▄     ███▌  ▄███▄▄▄██▀  ███    ███ ███   ███   ███    ███ ███        ███        ███▌ 
▀▀███▀▀▀     ███▌ ▀▀███▀▀▀██▄  ███    ███ ███   ███ ▀███████████ ███        ███        ███▌ 
  ███        ███    ███    ██▄ ███    ███ ███   ███   ███    ███ ███    █▄  ███    █▄  ███  
  ███        ███    ███    ███ ███    ███ ███   ███   ███    ███ ███    ███ ███    ███ ███  
  ███        █▀   ▄█████████▀   ▀██████▀   ▀█   █▀    ███    █▀  ████████▀  ████████▀  █▀   
                                                                                            ";
        static void Main(string[] args)
        {
            int input = 0;
            Console.WriteLine(TITLE);
            Console.WriteLine("Bienvenue au Fibonacci displayer 3000. \n© Danick Morin, 2025.");
            //alors alors comment dire
            Console.WriteLine("\nChoisissez une option:" +
                "\n1: Suite de Fibonnaci" +
                "\n2: Nombre carrées" +
                "\n3: Ratio d'or" +
                "\n4: FAQ");
            Console.Write("Votre choix : ");
            input = int.Parse(Console.ReadLine());

            if (input == 1)
            {
                PrintTitle();
                Console.Write("Combien de chiffres Fibonacci voulez-vous (de 1 à 46) ? : ");
                input = int.Parse(Console.ReadLine());
                CalculateFibonacciSequence(input);
            }
            if (input == 2)
            {
                PrintTitle();
                Console.Write("Combien de chiffres Fibonacci au carré voulez-vous (de 1 à 46) ? : ");
                input = int.Parse(Console.ReadLine());
                CalculateFibonacciSequence(input);



            }
            if (input == 3)
            {


            }
            if (input == 4)
            {


            }


        }
        static void PrintTitle()
        {
            Console.Clear();
            Console.WriteLine(TITLE);
        }

        static void CalculateFibonacciSequence(int number)
        {
            int range = number;
            int firstNumber = 0;
            int secondNumber = 1;
            int result = 0;
            for (int i = 0; i < range; i++)
            {
                result = firstNumber + secondNumber;
                Console.WriteLine(secondNumber);
                firstNumber = secondNumber;
                secondNumber = result;
            }
        }

        static void CalculateSquareNumber()
        {

        }


    }
}
